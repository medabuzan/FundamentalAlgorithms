# Assignment 5: Hash tables

For this week assignment you will have to implement the mandatory problems (the first 2) from the lab guide.